﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Segundo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Florianópolis");
            listBox1.Items.Add("Brasília");
            listBox1.Items.Add("Fortaleza");
            listBox1.Items.Add("Rio de Janeiro");
            listBox1.Items.Add("Ouro Preto");
            listBox1.Items.Add("Salvador");
            listBox1.Items.Add("São Thomé das Letras");
            listBox1.Items.Add("Belém do Pará");
            listBox1.Items.Add("Manaus");
            listBox1.Items.Add("Praia Grande");
            listBox1.Sorted = true;
            listBox1.SelectedIndex = 0;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "") // if (textBox1.Text==String.Empty) -> outra forma de verificar se o campo está vazio
                MessageBox.Show("Nome Vazio"); // aparece o alerta de nome vazio
            else
                MessageBox.Show("Nome: " + textBox1.Text); // aparece o nome digitado


            if (checkBox1.Checked)
                MessageBox.Show("Estrangeiro");
            else
                MessageBox.Show("Brasileiro");


            if (comboBox1.SelectedItem == null)
                MessageBox.Show("Tipo de viagem não selecionada");
            else
                MessageBox.Show("Tipo de Viagem: " + comboBox1.Text);



            if (comboBox2.SelectedIndex == -1)
                MessageBox.Show("Origem não selecionada");
            else
                MessageBox.Show("Origem: " + comboBox2.Text);



            MessageBox.Show("Destino: " + listBox1.SelectedItem);



            if (radioButton1.Checked)
                MessageBox.Show("Inclui aluguel de carro");
            else
                MessageBox.Show("Não inclui aluguel de carro");

            string preferencias = "";
            
            for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
            {
                preferencias = preferencias + "\n" + checkedListBox1.CheckedItems[i];
            }

            MessageBox.Show(preferencias);

        }
    }
}